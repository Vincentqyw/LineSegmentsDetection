close all
clear
clc

%Ron v2 kernels
MCMLSD_contours_folder = ['contours', filesep];
MCMLSD_PR_folder = ['PR-Alg-outputs', filesep];
 
roninputfname = 'MCMLSD_contours_test.mat';
ronoutputfname = 'PR_MCMLSD_test2.mat';
 
display('ron (v2)');
load([MCMLSD_contours_folder, roninputfname]);

for i=1:length(out)
    temp=out(i).contours(:,5).*out(i).contours(:,6);
    [~,ind]=sort(temp,'descend');
    out(i).contours = out(i).contours(ind,:);
end
pr = eval_PR(out, 'test');
save([MCMLSD_PR_folder, ronoutputfname], 'pr')