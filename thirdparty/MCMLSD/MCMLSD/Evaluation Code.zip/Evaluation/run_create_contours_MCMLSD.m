clear
clc
close all

addpath(genpath(pwd));
load('cameraParameters.mat')
load('ECCV_TrainingAndTestImageNumbers.mat')
load('Manhattan_Image_DB_Names.mat')
load('kernel_based_collected_results_newton.mat')
load('kernels_full_x04_th54.mat');

type = 'test';
r_res = 0.2;
th_res = 0.002;

%please set the the YorkUrbanDB directory here
dsetPath = fullfile('/YorkUrbanDB/');


folderpath = ['contours', filesep];
outfname = ['MCMLSD_contours_', type,'.mat'];
outputfile = [folderpath, outfname];

if strcmp(type, 'train')
    setIndexes = trainingSetIndex;
else
    setIndexes = testSetIndex;     
end

Nsetsamples = size(setIndexes,1);


idxTest = 1;
idxImgs = 0;
listing = dir(dsetPath);
ttlData = size(listing,1);
alpha = 0; %Threshold for line probabilities.
setDebug(0);
out = [];

for k=104:ttlData
    filename = listing(k).name;
    idx = strfind(filename, 'P10');
    if length(idx) == 1 && idx(1) == 1
        idxImgs = idxImgs + 1;
        if (idxTest <= Nsetsamples) && (idxImgs == setIndexes(idxTest))
            idxTest = idxTest + 1;
            filename
            imgFile = strcat(dsetPath, filename, filesep, filename, '.jpg');
            img = imread(imgFile);
            %Linear kernels
            lines = run_Manhattan_v3(kernels, kernels_flip, kernel_params, sig_bound, r_res, th_res, paramS, img, 0);
            lines = sortrows(lines, -8); % sort by probability
            length(lines)
            image.filname = filename;
            image.contours = lines;
            out = [out; image];
            save(outputfile, 'out');            
        end
    end
end