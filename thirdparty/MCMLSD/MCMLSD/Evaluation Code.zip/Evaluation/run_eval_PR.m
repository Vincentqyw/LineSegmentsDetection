close all
clear
clc

%Ron v2 kernels
MCMLSD_contours_folder = ['contours', filesep];
MCMLSD_PR_folder = ['PR-Alg-outputs', filesep];
 
roninputfname = 'MCMLSD_contours_test.mat';
ronoutputfname = 'PR_MCMLSD_test.mat';
 
display('ron (v2)');
load([MCMLSD_contours_folder, roninputfname]);
pr = eval_PR(out, 'test');
save([MCMLSD_PR_folder, ronoutputfname], 'pr')