close all
clear
clc

path_MCMLSD = ['PR-Alg-outputs', filesep, 'PR_MCMLSD_test'];
path_PPHT = ['PR-Alg-outputs', filesep, 'PR_PPHT_test.mat'];
path_LSWMS = ['PR-Alg-outputs', filesep, 'PR_LSWMS_test.mat'];
path_LSD = ['PR-Alg-outputs', filesep, 'PR_LSD_test.mat'];

methodsPath = {path_MCMLSD, path_LSD, path_LSWMS,path_PPHT};
legendstr = {'MCMLSD', 'LSD', 'SSWMS', 'PPHT'};
colorarray = ['r'; 'g'; 'b'; 'k'];

savefig = 1;
savepath = ['Plots', filesep];
visualizePRcurve_v4(methodsPath, legendstr, colorarray, savefig, savepath);