function [out] = samplecontours(lines, srate, frac, type)
% Description: Sample the set of lines at a particular rate. Out of all
% samples only a fraction is considered.
%
% Input:
%   - lines: Set of lines. Each line is dfined according to type. If type is
%       'gt' then a  line [x1 y1; x2 y2]. Otherwise [x1, y1, x2, y2]
%   - srate: Sample rate
%   - frac: Fraction of the total samples to be considered
%   - type: 'gt', 'al'
% Output:
%   - out: Struct with three fields. 'sampling' a [nx2] array with the
%   location of the sampling along the contours. 'labels' a [nx1] with the
%   label of the contour where the sampling belong to. 'limits' the
%   sampling locations where the lines start and finish in the 'sampling'
%   and 'labels' array.
%
% Author: Emilio Almazan
% Date: Nov 15

if strcmp(type, 'gt')
    Nlines = size(lines,1)/2;
else
    Nlines = size(lines,1);
end

sampling = [];
labels = [];
limits = [0];
s = RandStream('mt19937ar','Seed',0);
for i = 1:Nlines
    if strcmp(type, 'gt')
        p1 = lines(2*i - 1, :);
        p2 = lines(2*i, :);
    else
        p1 = lines(i, 1:2);
        p2 = lines(i, 3:4);     
    end
    [si, n] = sampling_line(p1,p2, srate);
    if frac ~= 1
        nred = floor(n*frac);    
        idx = sort(randperm(s,n, nred));
        sampling = [sampling; si(idx, :)];
        labels = [labels; zeros(nred, 1) + i]; 
        limits = [limits, limits(i) + nred];
    else
        sampling = [sampling; si];
        labels = [labels; zeros(n, 1) + i]; 
        limits = [limits, limits(i) + n];
    end
end
out.sampling = sampling;
out.labels = labels;
out.limits = limits;

        
        
        
        