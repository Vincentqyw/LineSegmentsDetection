function [pwise, lswise] = computePR(A, Cgt, Cal, Ngt, Nal)
% Description: Compute the precision and recall of the algorithm output
% 
% Input:
%   - A: Association matrix between gt and algorithm line segments
%   - C: Cost matrix (note the rows and columns must be consistent with A)
%   - ls1 and ls2: line segment information from the ground truth and
%   algorithm.
%
% Output:
%   - out: precision or recall
%
% Author: Emilio Almazan
% Date: Nov 15

idx = find(A);
tpgt = sum(Cgt(idx));
tpal = sum(Cal(idx));
pwise.recall = tpgt/Ngt;
pwise.precision = tpal/Nal;

Nlsgt = size(A,1);
Nlsal = size(A,2);
tplseg = sum(sum(A));
lswise.recall = tplseg/Nlsgt;
lswise.precision = tplseg/Nlsal;





