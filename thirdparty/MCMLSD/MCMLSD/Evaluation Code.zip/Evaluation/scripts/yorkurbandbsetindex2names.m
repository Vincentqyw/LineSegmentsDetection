function [setnames] = yorkurbandbsetindex2names(setIndex)
% Description: Recover the file names especified by a set of indexs
%
% Input:
%   - setIndex: [nx1] array of indexs in the YorkUrbanDB dataset
%
% Output:
%   - setnames: cell array with the names of the files
%
% Author: Emilio Almazan
% Date: Nov 15

% Load full results
% dSetPath = [filesep, 'Users', filesep, 'emilio', filesep, 'Dropbox', filesep, 'PostDoc', filesep,...
%     'Docear', filesep, 'projects', filesep, 'LineSegmentDet', filesep, 'Datasets', filesep, 'YorkUrbanDB', filesep,];
dSetPath = fullfile('/Users/yimingqian/Dropbox/PhD/Single View Image 3D Reconstruction/YorkUrbanDB/');
listing = dir(dSetPath);
Ndata = size(listing,1);

Nset = size(setIndex,1);
setnames = cell(Nset, 1);
idxTest = 1;
idxImgs = 0;
for k=1:Ndata
    filename = listing(k).name;
    idx = strfind(filename, 'P10');
    if length(idx) == 1 && idx(1) == 1
        idxImgs = idxImgs + 1;
        if (idxTest <= Nset) && (idxImgs == setIndex(idxTest))
            setnames{idxTest} = filename;
            idxTest = idxTest + 1;
        end
    end
end