function [ nLength ] = getTotalLengthSegments( lines )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

nLength = 0;
for i = 1:size(lines,1)
    s = lines(i, 1:4);
    n = sqrt((s(3)-s(1))^2 + (s(4) - s(2))^2);
    nLength = nLength + n;

end

