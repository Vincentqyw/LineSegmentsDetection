function [f] = showcontours(s, lines, type, filename, nl)
% Description: Plot sampling locations along the contours in an image
%
% Input: 
%   - s: array of sampling locations in the image [nx2]
%   - lines: array of lines defined by their endpoints. if type='gt' then a
%   line is defines as [x1, y1; x2, y2], otherwise [x1, y1, x2, y2]
%   - type: 'gt'/'al'
%   - filename: name of the image in the database YorkUrbanDB
%   - nl: total num. of lines
%
% Author: Emilio Almazan
% Date: Nov 15

% Load full results
dSetPath = [filesep, 'Users', filesep, 'emilio', filesep, 'Dropbox', filesep, 'PostDoc', filesep,...
    'Docear', filesep, 'projects', filesep, 'LineSegmentDet', filesep, 'Datasets', filesep, 'YorkUrbanDB', filesep,];

imgFile1 = strcat(dSetPath, filename, filesep, filename, '.jpg');
img = imread(imgFile1);
f = figure; imshow(img); hold on

if strcmp(type, 'gt')
    Nlines = size(lines,1)/2;
else
    Nlines = size(lines,1);
end
for i = 1:Nlines
    if strcmp(type, 'gt')
        p1 = lines(2*i - 1, :);
        p2 = lines(2*i, :);
    else
        p1 = lines(i, 1:2);
        p2 = lines(i, 3:4);     
    end
    plot([p1(1), p2(1)], [p1(2), p2(2)], 'r', 'Linewidth', 2);
end

if strcmp(type, 'gt')
    Ns = size(s,1);
    for j = 1:Ns
        plot(s(j,1), s(j,2), '.b', 'Markersize', 10);              
    end
end
removewhitepad;
% saveas(f, [filesep, 'Users', filesep, 'emilio', filesep, 'Dropbox', ...
%     filesep, 'PostDoc', filesep, 'Docear', filesep, 'projects', filesep, ...
%     'LineSegmentDet', filesep, 'Documentation', filesep, 'Evaluation', filesep, ...
%     'v4_II', filesep, 'figures', filesep 'algout', num2str(nl), '.pdf']);
% waitforbuttonpress;
% close(f);
