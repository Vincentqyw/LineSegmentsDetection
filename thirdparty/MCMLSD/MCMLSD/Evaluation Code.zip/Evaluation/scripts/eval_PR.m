function [out] = eval_PR(algout, runSetType)
% Description: Compute the precision and recall values for different number
% of algorithm line segments. The algorithm and ground truth are optimally
% associated 1 to 1 based on the amount of associated locations. The
% precision and recall are computed at two levels: line segment and pixels.
% Input:
%   - algout: Set of algorithm detected contours in the dataset
%   - runSettype: train / test
%
% Output:
%   - Set of precision and recall (line segment and pixel level) values for
% different number of algorithm contours.
%
% Preconditions: algout is an array of structs where each position stores
% the name of an image in the dataset and the array with the detected
% contours [x1, y1, x2, y2]
%
% Author: Emilio Almazan
% Date: Nov 15

debug_gt = 0;
debug_al = 0;

% dSetPath = [filesep, 'Users', filesep, 'emilio', filesep, 'Dropbox', filesep, 'PostDoc', filesep,...
%     'Docear', filesep, 'projects', filesep, 'LineSegmentDet', filesep, 'Datasets', filesep, 'YorkUrbanDB', filesep,];
dSetPath = fullfile('/Users/yimingqian/Dropbox/PhD/Single View Image 3D Reconstruction/YorkUrbanDB/');

%load train and test indexs
% path_traintestnum = [filesep, 'Users', filesep, 'emilio', filesep, 'Dropbox', filesep, 'PostDoc', filesep, 'Docear', filesep,...
%      'projects', filesep, 'LineSegmentDet', filesep, 'Datasets', filesep, 'YorkUrbanDB', filesep, 'ECCV_TrainingAndTestImageNumbers.mat'];
 path_traintestnum = fullfile('/Users/yimingqian/Dropbox/PhD/Single View Image 3D Reconstruction/YorkUrbanDB/ECCV_TrainingAndTestImageNumbers.mat');

load(path_traintestnum)

if strcmp(runSetType, 'train')
    setIndex = trainingSetIndex;
else
    setIndex = testSetIndex;
end    
Nset = size(setIndex,1);
setnames = yorkurbandbsetindex2names(setIndex);

nlinesset = [10, 30, 50, 70, 90, 110, 130, 150, 170, 190, 210, 230, 250, ...
    270, 290, 310, 330, 350, 370, 390, 410, 430, 450, 470, 500];
Nlset = size(nlinesset, 2);
out = [];
%parameters
srate = 1;
red = 1;
gamma = sqrt(2^2 + 2^2); 
r_pwise = zeros(Nset, Nlset) + inf;
p_pwise = zeros(Nset, Nlset) + inf;
lenghtLines = zeros(Nset, Nlset) + inf;
fnames = cell(Nset, 1);
for i = 1:Nset %total images   
   tic
    display(['Image ', num2str(i), ' out of ', num2str(Nset)]);
    fname = setnames{i}
    if ~strcmp(fname, algout(i).filname)
        error('Error');
    end
    gtFile = strcat(dSetPath, fname, filesep, fname, 'LinesAndVP.mat');
    outgt = load(gtFile);
    gt = samplecontours(outgt.lines, srate, red, 'gt');
    Ngtlseg = size(outgt.vp_association, 1);
    Ngt = size(gt.sampling, 1);
    if debug_gt
        showcontours(gt.sampling, outgt.lines, 'gt', fname);
    end
    %al = samplecontours(algout(i).contours, srate, red, 'al');
    Nallsegreal = size(algout(i).contours, 1);
    Nlines = min(Nallsegreal, nlinesset(end));
    [D, al] = computeCostmatrixRed(algout(i), srate, gt, gamma, Nlines);    
    if debug_al
        showcontours(al.sampling, algout(i).contours(1:20, :), 'al', fname);
    end   
    %D = computesamplingdist(gt.sampling,al.sampling, gamma);
    for j = 1:Nlset
        Nallseg = nlinesset(j);
        if Nallseg <= Nallsegreal
            [Cgt, Cal] = computecostmatrix(D, gt, al, Ngtlseg, Nallseg);
            A = Hungarian(-Cgt);            
            %Standard Precision Recall
            [pwise, lswise] = computePR(A, Cgt, Cal, Ngt, al.allimits(Nallseg+1));
            lenghtLines(i,j) = getTotalLengthSegments(algout(i).contours(1:Nallseg, :));
            p_pwise(i, j) = pwise.precision;
            r_pwise(i, j) = pwise.recall;
        end
    end
    fnames{i} = fname;
    toc
end
out.pixelwise.precision = p_pwise;
out.pixelwise.recall = r_pwise;
out.nlines = nlinesset;
out.lenghtLines = lenghtLines;
out.filenames = fnames;