function [out, num_steps] = sampling_line(p1, p2, samplingRate)
    
    out = [];
    v = p2 - p1;
    n = norm(v);
    v_unit = v/n;
    v_step = v_unit*samplingRate;
    num_steps = floor(n/samplingRate);
    p_inter = p1;
    out = [out; p_inter];
    for j = 1:num_steps             
        p_inter = p_inter + v_step;
        out = [out; p_inter];
    end
    num_steps = num_steps + 1;
end