function [Cgt, Cal] = computecostmatrix(D, gt, al, nlgt, nlal)
% Description: Compute the cost matrix at line segment level between gt and
% algorithm contours. The cost of associations between two line segments is
%computed based on the number of associated locations between both
%contours. Since the location association is not 1 to 1 the cost of
%associating to line segments might be different from the algorithm and gt
%perspective. Two cost matrix are computed (gt and algorithm)
%
% Input:
%   - gt: Data struct from the ground truth ('sampling', 'labels',
%   'limits').
%   - al: Data struct from the algorithm output (same as gt).
%   - nlines: Number of algorithm line segments to consider
%
% Output:
%   - Cgt: Cost matrix based on the gt associations where line segments 
%   with none locations associated are given a -inf value
%   - Cal: Cost matrix based on the algorithm associations where line segments 
%   with none locations associated are given a -inf value


Cgt = zeros(nlgt, nlal) - inf;
Cal = zeros(nlgt, nlal) - inf;

for i = 1:nlgt
    gtls = [gt.limits(i) + 1, gt.limits(i+1)];
    for j = 1:nlal 
       alls = [al.limits(j) + 1, al.limits(j+1)];
       droi = D(gtls(1):gtls(2), alls(1):alls(2));
       alweight = size(find(sum(isfinite(droi))),2);
       if alweight ~= 0
           Cal(i, j) = alweight;
       end
       gtweight = size(find(sum(isfinite(droi'))),2);
       if gtweight ~= 0
           Cgt(i, j) = gtweight;
       end
    end    
end

