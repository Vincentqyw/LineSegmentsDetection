function [C, sout] = partialcostmatrix(s, gtsamp, gamma)
% Description: Filter out those sampling locations that are not associated
% with any ground truth sample.
%
% Input:
%   - s: [nx2] array of locations along a line segment
%   - gt: [nx2] array of locations along all gt line segments
%   - gamma: threshold for the association distance
%
% Output:
%   - C: cost matrix computed as the euclidean distance between gt and
%   algorithm samples (note that algorithm samples with a distance higher
%   than gamma are not included in the matrix)
%   - sout: Final list of algorithm samples that have gt association
%
% Author: Emilio Almazan
% Date: Nov 15

C = pdist2(gtsamp,s);
idx = find(C <= gamma);
[row, col] = ind2sub(size(C), idx);
col = unique(col);
C = C(:, col);
idx = find(C > gamma);
C(idx) = inf;
sout = s(col, :);



