function visualizePRcurve_v4(methodsPath, legendstr, colorarray, saveplot, savepath)
% Description: Plot the precision and recall curve as a function of the number of
% line segments. 
%
% Input:
%   - methodsPath: cell array with the path to the method results
%   - legendstr: Name of the methods to be evaluated. It will be display in
%   the legend of the plot.
%   - colorarray: array of char colors to define each method curve.
%
% Author: Emilio Almazan
% Date: Nov 15

N = size(methodsPath,2);
hpixel = [];
hpixelr = [];
hpixelrLength = [];
fpixel = figure; hold on
fpixelr = figure;
fpixelrLength = figure;

for i = 1:N
    load(methodsPath{i});
    lineset = pr.nlines;
    nlineset = size(lineset,2);
    ravg = zeros(nlineset,2);
    pavg = zeros(nlineset,2);
    f1avg = zeros(nlineset,2);
    lenghtLinesAvg = zeros(nlineset,1);
    for j = 1:nlineset
        [pavg(j,1), ravg(j,1)] = computemean(pr.pixelwise.recall, pr.pixelwise.precision, j);
        allLengths = pr.lenghtLines(:,j);
        lenghtLinesAvg(j) = mean(allLengths(isfinite(allLengths)));
    end
    %Precision - Recall
    figure(fpixel);
    h1 = plot(ravg(:,1), pavg(:,1), 'Color', colorarray(i), 'Linewidth', 2);
    hpixel = [hpixel, h1];
    plot(ravg(:,1), pavg(:,1), 's', 'Color', colorarray(i), 'Markerfacecolor', colorarray(i), ...
        'Markersize', 10);   
    
    % Recall - # lines
    figure(fpixelr);
    h1 = plot(lineset, ravg(:,1), 'Color', colorarray(i), 'Linewidth', 2);
    hold on
    hpixelr = [hpixelr, h1];
    plot(lineset, ravg(:,1), 's', 'Color', colorarray(i), 'Markerfacecolor', colorarray(i), ...
        'Markersize', 10); 
    
    % Recall - length of lines
    figure(fpixelrLength)
    h1 = plot(lenghtLinesAvg, ravg(:,1), 'Color', colorarray(i), 'Linewidth', 2);
    hold on
    hpixelrLength = [hpixelrLength, h1];
    plot(lenghtLinesAvg, ravg(:,1), 's', 'Color', colorarray(i), 'Markerfacecolor', colorarray(i), ...
        'Markersize', 10); 
      
    
end
figure(fpixel);
h_legend = legend(hpixel, legendstr, 'Location', 'southeast');
set(h_legend,'FontSize',20);
ylabel('Precision', 'FontSize', 26);
xlabel('Recall', 'FontSize', 26);
axis([0 1, 0 1]);
set(gca,'Fontsize', 24);
grid on
box on
removewhitepad;
if saveplot
    saveas(fpixel, [savepath, 'PR_pixel.pdf']);
end

figure(fpixelr);
h_legend = legend(hpixelr, legendstr, 'Location', 'Southeast');
set(h_legend,'FontSize',20, 'location', 'northwest');
ylabel('Recall', 'FontSize', 26);
xlabel('Number of line segments', 'FontSize', 26);
axis([0 500, 0 1]);
set(gca,'Fontsize', 24);
grid on
box on
removewhitepad;
if saveplot
    saveas(fpixelr, [savepath, 'R_pixel.pdf']);
end

figure(fpixelrLength)
h_legend = legend(hpixelrLength, legendstr, 'Location', 'Southeast');
set(h_legend,'FontSize',20, 'location', 'northeast');
ylabel('Recall', 'FontSize', 26);
xlabel('Total line segment length (pixels)', 'FontSize', 26);
axis([0 20000, 0 1]);
set(gca,'Fontsize', 24);
grid on
box on
removewhitepad;
if saveplot
    saveas(fpixelrLength, [savepath, 'RL_pixel.pdf']);
end