function [p, r] = computemean(recall, precision, id)
% Description: compute the mean recall and precision for a given number of
% lines in all dataset
%
% Input:
%   - recall: [nx6] array of recall values for 6 different number of lines
%   for n images in the dataset
%   - precision: [nx6] array of precision values for 6 different number of lines
%   for n images in the dataset
%   - id: column to study in the precision and recall arrays. It represents
%   a number of line segments
%
% Output:
%   - p, r: average precision and recall for a given number of lines
%
% Note: The arrays recall and precision are filled with infinite values in
% those cases where there were not detected that amount of line segments
%
% Author: Emilio Almazan
% Date: Nov 15

pj = precision(:,id);
p = mean(pj(isfinite(pj)));

rj = recall(:,id);
r = mean(rj(isfinite(rj)));