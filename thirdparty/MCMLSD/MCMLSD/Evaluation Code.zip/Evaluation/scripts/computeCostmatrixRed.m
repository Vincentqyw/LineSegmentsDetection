function [C, alout] = computeCostmatrixRed(algout, srate, gt, gamma, Nlines)
% Description: Compute the cost matrix at sampling level using only the
% associated algorithm samplings and discarding the rest. This way the cost
% matrix is much smaller and the association can be performed faster.
%
% Input:
%   - algout: Algorithm results for the current image
%   - srate: sampling rate
%   - gt: sampling locations from the gt
%   - gamma: association threshold
%   - Nlines: Number of algorithm line segments to be considered. It will
%   be the minimum of the total algorithm detected contours and the maximum
%   number of contours used for evaluation
%
% Output:
%   - C: Reduced cost matrix with all gt sampling and only associated
%   algorithm samplings.
%   - alout: data structure with three fields: 'allbls': [nx1] array with 
%   the labels of the contours of the samplings. 'allim': [mx1] array with 
%   the locations that delimit the contours in the array of samplings and 
%   labels. 'alsam': [nx2] array of sampling locations along the algorithm 
%   detected contours.
%
% Author: Emilio Almazan
% Date: Nov 15

C = [];
allbls = [];
alllabels = [];
allim = [0]; %locations that delimit line segments in the array of samplings
allimits = [0];
alsam = [];
allsampling = [];
    
for j = 1:Nlines
    l = algout.contours(j, :);
    %nx2 of sampling locatins along line segment
    si = sampling_line(l(1:2),l(3:4), srate);
    n = size(si,1);
    allsampling = [allsampling; si];
    allimits = [allimits, allimits(end)+n];
    alllabels = [alllabels; zeros(n, 1) + j];
    %remove non-associated locations
    [ci, si] = partialcostmatrix(si, gt.sampling, gamma); 
    alsam = [alsam; si];
    n = size(si,1);
    allbls = [allbls; zeros(n, 1) + j];
    allim = [allim, allim(end)+n];
    C = [C, ci];       
end
alout.allsampling = allsampling;
alout.alllabels = alllabels;
alout.allimits = allimits;
alout.sampling = alsam;
alout.labels = allbls;
alout.limits = allim;