close all
clear
clc

method1 = ['PR-Alg-outputs', filesep, 'PR_MCMLSD_test1.mat'];
method2 = ['PR-Alg-outputs', filesep, 'PR_MCMLSD_test2.mat'];
method3 = ['PR-Alg-outputs', filesep, 'PR_MCMLSD_test3.mat'];
method4 = ['PR-Alg-outputs', filesep, 'PR_MCMLSD_test4.mat'];

methodsPath = {method1, method2, method3,method4};
legendstr = {'Method 1', 'Method 2', 'Method 3', 'Method 4'};
colorarray = ['r'; 'g'; 'b'; 'k'];

savefig = 1;
savepath = ['Plots', filesep];
visualizePRcurve_v4(methodsPath, legendstr, colorarray, savefig, savepath);